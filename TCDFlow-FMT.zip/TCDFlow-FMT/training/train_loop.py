# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the CC-by-NC license found in the
# LICENSE file in the root directory of this source tree.
import argparse
import gc
import logging
import math
from typing import Iterable
import os
import matplotlib.pyplot as plt
import torch
from tqdm import tqdm
from flow_matching.path import CondOTProbPath, MixtureDiscreteProbPath
from flow_matching.path.scheduler import PolynomialConvexScheduler
from models.ema import EMA
from torch.nn.parallel import DistributedDataParallel
from torchmetrics.aggregation import MeanMetric
from training.grad_scaler import NativeScalerWithGradNormCount
import torch
import scipy.io as scio
import torch.nn.functional as F
logger = logging.getLogger(__name__)
MASK_TOKEN = 256
PRINT_FREQUENCY = 50

def skewed_timestep_sample(num_samples: int, device: torch.device) -> torch.Tensor:
    P_mean = -1.2
    P_std = 1.2
    rnd_normal = torch.randn((num_samples,), device=device)
    sigma = (rnd_normal * P_std + P_mean).exp()
    time = 1 / (1 + sigma)
    time = torch.clip(time, min=0.0001, max=1.0)
    return time


def train_one_epoch(
    model: torch.nn.Module,
    data_loader: Iterable,
    optimizer: torch.optim.Optimizer,
    lr_schedule: torch.torch.optim.lr_scheduler.LRScheduler,
    device: torch.device,
    epoch: int,
    loss_scaler: NativeScalerWithGradNormCount,
    args: argparse.Namespace,
):

    gc.collect()
    model.train(True)
    batch_loss = MeanMetric().to(device, non_blocking=True)
    epoch_loss = MeanMetric().to(device, non_blocking=True)

    batch_mse_loss = MeanMetric().to(device, non_blocking=True)
    def get_encoder_dim_from_model(model):

        if isinstance(model, EMA):
            base_model = model.model

        elif isinstance(model, DistributedDataParallel):
            base_model = model.module

            if isinstance(base_model, EMA):
                base_model = base_model.model
        else:
            base_model = model


        if hasattr(base_model, 'condition_encoder') and hasattr(base_model.condition_encoder, 'dim'):
            return base_model.condition_encoder.dim
        else:

            logger.warning("Could not find encoder_dim from model, using default 384")
            return 384

    use_mse_loss = getattr(args, 'use_mse_loss', True)
    if use_mse_loss:
        logger.info("Using MSE loss")
    else:
        logger.info("MSE loss disabled")


    accum_iter = args.accum_iter
    if args.discrete_flow_matching:
        scheduler = PolynomialConvexScheduler(n=3.0)
        path = MixtureDiscreteProbPath(scheduler=scheduler)
    else:
        path = CondOTProbPath()


    for data_iter_step, (samples, labels) in enumerate(data_loader):
        current_step = epoch * len(data_loader) + data_iter_step
        if data_iter_step % accum_iter == 0:
            optimizer.zero_grad()
            batch_loss.reset()
            if data_iter_step > 0 and args.test_run:
                break

        samples = samples.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)

        if torch.rand(1) < args.class_drop_prob:
            conditioning = {}
        else:
            conditioning = {"label": labels}

        if args.discrete_flow_matching:
            samples = (samples * 255.0).to(torch.long)
            t = torch.torch.rand(samples.shape[0]).to(device)


            x_0 = (
                torch.zeros(samples.shape, dtype=torch.long, device=device) + MASK_TOKEN
            )
            path_sample = path.sample(t=t, x_0=x_0, x_1=samples)


            logits = model(path_sample.x_t, t=t, extra=conditioning)
            loss = torch.nn.functional.cross_entropy(
                logits.reshape([-1, 257]), samples.reshape([-1])
            ).mean()
        else:

            samples = samples * 2.0 - 1.0
            noise = torch.randn_like(samples).to(device)
            if args.skewed_timesteps:
                t = skewed_timestep_sample(samples.shape[0], device=device)
            else:
                t = torch.torch.rand(samples.shape[0]).to(device)
            path_sample = path.sample(t=t, x_0=noise, x_1=samples)
            x_t = path_sample.x_t
            u_t = path_sample.dx_t

            with torch.cuda.amp.autocast():
                model_output, intermediate_features = target_for_feat(
                        x_t, t, extra=conditioning, return_intermediate=True
                    )

                B, C, H, W = model_output.shape
                channel_weights = torch.ones(C, device=model_output.device)
                c_w = channel_weights.view(1, C, 1, 1).expand_as(model_output)
                diff_sq =c_w * torch.pow(model_output - u_t, 2)
                per_sample_mse = diff_sq.mean(dim=(1, 2, 3))
                mse_loss = per_sample_mse.mean()

                loss = 0.0
                if use_mse_loss:
                    loss += mse_loss
                    batch_mse_loss.update(mse_loss)
                else:
                    batch_mse_loss.update(0.0)

        loss_value = loss.item()
        batch_loss.update(loss)
        epoch_loss.update(loss)

        if not math.isfinite(loss_value):
            raise ValueError(f"Loss is {loss_value}, stopping training")

        loss /= accum_iter
        apply_update = (data_iter_step + 1) % accum_iter == 0
        loss_scaler(
            loss,
            optimizer,
            parameters=model.parameters(),
            update_grad=apply_update,
        )
        if apply_update and isinstance(model, EMA):
            model.update_ema()
        elif (
            apply_update
            and isinstance(model, DistributedDataParallel)
            and isinstance(model.module, EMA)
        ):
            model.module.update_ema()

        lr = optimizer.param_groups[0]["lr"]
        if data_iter_step % PRINT_FREQUENCY == 0:
            logger.info(
                f"Epoch {epoch} [{data_iter_step}/{len(data_loader)}]: loss = {batch_loss.compute()}, lr = {lr}"
            )
            log_msg = f"Epoch {epoch} [{data_iter_step}/{len(data_loader)}]: loss = {batch_loss.compute():.6f}, lr = {lr:.2e}"
            log_msg += f", mse = {batch_mse_loss.compute():.6f}"
            logger.info(log_msg)
    lr_schedule.step()
    return {
        "loss": float(epoch_loss.compute().detach().cpu()),
        "mse_loss": float(batch_mse_loss.compute().detach().cpu()) if use_mse_loss else 0.0,
    }





