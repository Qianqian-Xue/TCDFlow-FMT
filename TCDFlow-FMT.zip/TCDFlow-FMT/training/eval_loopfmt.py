# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the CC-by-NC license found in the
# LICENSE file in the root directory of this source tree.

import logging
from pathlib import Path
import torch
from flow_matching.solver.ode_solver import ODESolver
from flow_matching.utils import ModelWrapper
from models.discrete_unet import DiscreteUNetModel
from models.ema import EMA
from torch.nn.modules import Module
from torch.nn.parallel import DistributedDataParallel
import numpy as np
import matplotlib.pyplot as plt
import scipy.io as scio
from functools import partial
from torchmetrics.classification import Dice, BinaryJaccardIndex

logger = logging.getLogger(__name__)

PRINT_FREQUENCY = 50


class CFGScaledModel(ModelWrapper):
    def __init__(self, model: Module):
        super().__init__(model)
        self.nfe_counter = 0

    def forward(
            self, x: torch.Tensor, t: torch.Tensor, cfg_scale: float, label: torch.Tensor
    ):
        module = (
            self.model.module
            if isinstance(self.model, DistributedDataParallel)
            else self.model
        )
        is_discrete = isinstance(module, DiscreteUNetModel) or (
                isinstance(module, EMA) and isinstance(module.model, DiscreteUNetModel)
        )
        assert (
                cfg_scale == 0.0 or not is_discrete
        ), f"Cfg scaling does not work for the logit outputs of discrete models. Got cfg weight={cfg_scale} and model {type(self.model)}."
        t = torch.zeros(x.shape[0], device=x.device) + t

        if cfg_scale == 0.0:
            # Model is fully conditional, no cfg weighting needed
            with torch.cuda.amp.autocast():
                result = self.model(x, t, extra={"label": label})
        elif cfg_scale == -1.0:
            # Model is unconditional, no cfg weighting needed
            with torch.cuda.amp.autocast():
                result = self.model(x, t, extra={})
        else:
            with torch.cuda.amp.autocast():
                conditional = self.model(x, t, extra={"label": label})
                condition_free = self.model(x, t, extra={})
            result = (1.0 + cfg_scale) * conditional - cfg_scale * condition_free

        self.nfe_counter += 1
        if is_discrete:
            return torch.softmax(result.to(dtype=torch.float32), dim=-1)
        else:
            return result.to(dtype=torch.float32)

    def reset_nfe_counter(self) -> None:
        self.nfe_counter = 0

    def get_nfe(self) -> int:
        return self.nfe_counter

def save_fmt_reconstruction(save_dir: Path, idx: int, pred: np.ndarray, gt: np.ndarray):

    save_dir.mkdir(parents=True, exist_ok=True)


    if pred.ndim == 4:
        pred = pred[0, 0]
        gt   = gt[0, 0]
    elif pred.ndim == 3 and pred.shape[0] == 1:
        pred = pred[0]
        gt   = gt[0]

    slice_idx = 7
    gt_slice    = np.clip(gt[slice_idx], 0, 1)
    pred_slice  = np.clip(pred[slice_idx], 0, 1)

    plt.figure(figsize=(12, 6))

    plt.subplot(1, 2, 1)
    im1 = plt.imshow(gt_slice, cmap='viridis', vmin=0, vmax=1)
    plt.title(f"Ground Truth (slice {slice_idx})", fontsize=14)
    plt.colorbar(im1, fraction=0.046, pad=0.04)
    plt.axis('off')

    plt.subplot(1, 2, 2)
    im2 = plt.imshow(pred_slice, cmap='viridis', vmin=0, vmax=1)
    plt.title(f"Reconstruction (slice {slice_idx})", fontsize=14)
    plt.colorbar(im2, fraction=0.046, pad=0.04)
    plt.axis('off')

    plt.suptitle(f"Sample {idx}", fontsize=16)
    plt.tight_layout()
    plt.savefig(save_dir / f"compare_{idx:04d}_slice{slice_idx}.png", dpi=150, bbox_inches='tight')
    plt.close()

    # 保存完整 3D mat
    scio.savemat(save_dir / f"recon_{idx:04d}.mat", {
        'reconstruction': pred.astype(np.float32),
        'ground_truth':   gt.astype(np.float32),
    })


def eval_model(
    model,
    data_loader,
    device,
    epoch: int,
    fid_samples: int,
    args,
    save_reconstructions: bool = True,
):
    if hasattr(args, 'seed'):
        torch.manual_seed(args.seed)
        np.random.seed(args.seed)
    else:
        torch.manual_seed(42)
        np.random.seed(42)
    model.eval()
    cfg_scaled_model = CFGScaledModel(model=model)


    solver = ODESolver(velocity_model=cfg_scaled_model)


    logger.info("FID computation is completely DISABLED for 3D FMT task")


    sample_fn = partial(
        solver.sample,
        time_grid=torch.tensor([0.0, 1.0], device=device),
        method=args.ode_method,
        atol=args.ode_options.get("atol", 1e-5),
        rtol=args.ode_options.get("rtol", 1e-5),
        step_size=args.ode_options.get("step_size"),
        cfg_scale=args.cfg_scale,
    )


    recon_dir = None
    if save_reconstructions and args.output_dir:
        recon_dir = Path(args.output_dir) / f"recon_epoch_{epoch}"
        logger.info(f"Saving reconstructions → {recon_dir}")

    metrics = {}
    total_dice = total_le = total_ssim = total_psnr = 0.0
    count = 0

    with torch.no_grad():
        for batch_idx, (gts, labels) in enumerate(data_loader):
            gts    = gts.to(device)
            labels = labels.to(device)


            pred_list = []
            for _ in range(getattr(args, "n_ensemble", 1)):
                noise = torch.randn_like(gts)
                pred  = sample_fn(x_init=noise, label=labels)
                pred  = torch.clamp(pred * 0.5 + 0.5, 0, 1)
                pred_list.append(pred)
            pred = torch.stack(pred_list).mean(0)

            pred_np = pred.cpu().numpy()
            gt_np   = gts.cpu().numpy()

            for i in range(pred.shape[0]):
                p = pred_np[i]
                g = gt_np[i]

                if p.ndim == 4: p = p[0, 0] if p.shape[0] == 1 else p[0]
                if g.ndim == 4: g = g[0, 0] if g.shape[0] == 1 else g[0]

                global_idx = batch_idx * gts.shape[0] + i


                if recon_dir:
                    save_fmt_reconstruction(recon_dir, global_idx, p, g)


                thresh = max(0.1 * p.max(), 0.05)
                p_bin = (p > thresh)
                g_bin = (g > 0.02)

                dice = 2.0 * (p_bin & g_bin).sum() / (p_bin.sum() + g_bin.sum() + 1e-6)
                total_dice += dice

                if g_bin.sum() > 0 and p_bin.sum() > 0:
                    g_center = np.argwhere(g_bin).mean(axis=0)
                    p_center = np.argwhere(p_bin).mean(axis=0)
                    total_le += np.linalg.norm(g_center - p_center)
                else:
                    total_le += 999.0

                from skimage.metrics import structural_similarity as ssim, peak_signal_noise_ratio as psnr
                total_ssim += ssim(g, p, data_range=1.0)
                total_psnr += psnr(g, p, data_range=1.0)

                count += 1

            if args.test_run:
                break


    if count > 0:
        metrics["eval_dice"] = total_dice / count
        metrics["eval_le"]   = total_le   / count
        metrics["eval_ssim"] = total_ssim / count
        metrics["eval_psnr"] = total_psnr / count

        logger.info(f"Epoch {epoch} | Dice: {metrics['eval_dice']:.4f} | "
                    f"LE: {metrics['eval_le']:.3f}mm | SSIM: {metrics['eval_ssim']:.4f} | PSNR: {metrics['eval_psnr']:.2f}")

    return metrics
