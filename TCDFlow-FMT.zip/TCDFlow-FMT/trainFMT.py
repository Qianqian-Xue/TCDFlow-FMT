import datetime
import json
import logging
import os
import sys
import time
from pathlib import Path
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import torchvision.datasets as datasets
from models.model_configs import instantiate_model
from train_arg_parserFMT import get_args_parserFMT
from torch.utils.data import DataLoader
from training import distributed_mode
from training.eval_loopfmt import eval_model
from training.grad_scaler import NativeScalerWithGradNormCount as NativeScaler
from training.load_and_save import load_model, save_model
from training.train_loop import train_one_epoch
from FMTsdata import FMTsDataset
from valFMTsdata import valFMTsDataset
logger = logging.getLogger(__name__)

def main(args):
    logging.basicConfig(
        level=logging.INFO,
        stream=sys.stdout,
        format="%(asctime)s %(levelname)-8s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    distributed_mode.init_distributed_mode(args)

    logger.info("job dir: {}".format(os.path.dirname(os.path.realpath(__file__))))
    logger.info("{}".format(args).replace(", ", ",\n"))
    if args.output_dir and distributed_mode.is_main_process():
        args_filepath = Path(args.output_dir) / "args.json"
        logger.info(f"Saving args to {args_filepath}")
        with open(args_filepath, "w") as f:
            json.dump(vars(args), f)
    device = torch.device(args.device)
    seed = args.seed + distributed_mode.get_rank()
    torch.manual_seed(seed)
    np.random.seed(seed)

    cudnn.benchmark = True

    logger.info(f"Initializing Dataset: FMTsDataset")
    dataset_train = FMTsDataset(args.data_dir, test_flag=False)
    dataset_val = valFMTsDataset(args.valdata_dir, test_flag=True)
    logger.info(dataset_train)
    logger.info(dataset_val)

    logger.info("Intializing DataLoader")
    num_tasks = distributed_mode.get_world_size()
    global_rank = distributed_mode.get_rank()
    ##分布式
    if args.distributed:

        sampler_train = torch.utils.data.DistributedSampler(
            dataset_train,
            num_replicas=num_tasks,
            rank=global_rank,
            shuffle=True
        )
        shuffle_train = False
    else:
        sampler_train = None
        shuffle_train = True

    data_loader_train = torch.utils.data.DataLoader(
        dataset_train,
        sampler=sampler_train,
        shuffle=shuffle_train,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        pin_memory=args.pin_mem,
        drop_last=True
    )
    logger.info(f"Train DataLoader: batch_size={args.batch_size}, num_workers={args.num_workers}")

    data_loader_val = torch.utils.data.DataLoader(
        dataset_val,
        shuffle=False,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        pin_memory=args.pin_mem,
        drop_last=False,
    )

    # define the model
    logger.info("Initializing Model")
    model = instantiate_model(
        architechture=args.dataset + ("_condition" if args.condition else ""),
        is_discrete=args.discrete_flow_matching,
        use_ema=args.use_ema,
    )

    model.to(device)

    model_without_ddp = model
    if args.distributed:
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.gpu],find_unused_parameters=True)
        model_without_ddp = model.module
    logger.info(str(model_without_ddp))

    eff_batch_size = (
        args.batch_size * args.accum_iter
    )
    if args.distributed:
        eff_batch_size *= distributed_mode.get_world_size()

    logger.info(f"Learning rate: {args.lr:.2e}")

    logger.info(f"Accumulate grad iterations: {args.accum_iter}")
    logger.info(f"Effective batch size: {eff_batch_size}")

    optimizer = torch.optim.AdamW(model_without_ddp.parameters(), lr=args.lr, betas=args.optimizer_betas)
    if args.decay_lr:
        lr_schedule = torch.optim.lr_scheduler.LinearLR(
            optimizer,
            total_iters=args.epochs,
            start_factor=1.0,
            end_factor=1e-8 / args.lr,
        )
    else:
        lr_schedule = torch.optim.lr_scheduler.ConstantLR(
            optimizer, total_iters=args.epochs, factor=1.0
        )

    logger.info(f"Optimizer: {optimizer}")
    logger.info(f"Learning-Rate Schedule: {lr_schedule}")

    loss_scaler = NativeScaler()

    load_model(
        args=args,
        model_without_ddp=model_without_ddp,
        optimizer=optimizer,
        loss_scaler=loss_scaler,
        lr_schedule=lr_schedule,
    )

    train_losses = []
    train_mse_losses = []

    eval_metrics = {
        'dice': [],
        'le': [],
        'ssim': []
    }
    logger.info(f"Start from {args.start_epoch} to {args.epochs} epochs")
    start_time = time.time()
    for epoch in range(args.start_epoch, args.epochs):
        if args.distributed:
            data_loader_train.sampler.set_epoch(epoch)
        if not args.eval_only:
            train_stats = train_one_epoch(
                model=model,
                data_loader=data_loader_train,
                optimizer=optimizer,
                lr_schedule=lr_schedule,
                device=device,
                epoch=epoch,
                loss_scaler=loss_scaler,
                args=args,
            )
            train_losses.append(train_stats.get('loss', 0))
            train_mse_losses.append(train_stats.get('mse_loss', 0))

            log_stats = {
                 **{f"train_{k}": v for k, v in train_stats.items()},
                "epoch": epoch,
            }

        else:
            log_stats = {
                "epoch": epoch,
            }

        if args.output_dir and (
            (args.eval_frequency > 0 and (epoch + 1) % args.eval_frequency == 0)
            or args.eval_only
            or args.test_run
        ):
            if not args.eval_only:
                save_model(
                    args=args,
                    model=model,
                    model_without_ddp=model_without_ddp,
                    optimizer=optimizer,
                    lr_schedule=lr_schedule,
                    loss_scaler=loss_scaler,
                    epoch=epoch,
                )
            if args.distributed:
                data_loader_train.sampler.set_epoch(0)
            if distributed_mode.is_main_process():
                fid_samples = args.fid_samples - (num_tasks - 1) * (
                        args.fid_samples // num_tasks
                )
            else:
                fid_samples = args.fid_samples // num_tasks


            eval_stats = eval_model(
                model,
                data_loader_val,
                device,
                epoch=epoch,
                fid_samples=fid_samples,
                args=args,
            )
            eval_metrics['dice'].append(eval_stats.get('dice', 0))
            eval_metrics['le'].append(eval_stats.get('le', 0))
            eval_metrics['ssim'].append(eval_stats.get('ssim', 0))
            log_stats.update({f"eval_{k}": v for k, v in eval_stats.items()})

        if args.output_dir and distributed_mode.is_main_process():
            log_file = Path(args.output_dir) / "log.txt"
            with open(log_file, "a", encoding="utf-8") as f:
                if not args.eval_only and 'train_loss' in log_stats:
                    train_line = f"Epoch {epoch:3d} | [{len(data_loader_train)}/{len(data_loader_train)}] | " \
                                 f"Loss: {log_stats['train_loss']:.6f} | LR: {log_stats.get('train_lr', args.lr):.2e}"
                    f.write(train_line + "\n")
                    print(f"\033[92m{train_line}\033[0m")

                if 'eval_dice' in log_stats:
                    eval_line = f"★ Epoch {epoch:3d} | Dice: {log_stats['eval_dice']:.4f} | " \
                                f"LE: {log_stats['eval_le']:.3f}mm | SSIM: {log_stats['eval_ssim']:.4f}"
                    is_best = False
                    if not hasattr(args, 'best_dice') or log_stats['eval_dice'] > args.best_dice:
                        args.best_dice = log_stats['eval_dice']
                        is_best = True
                        eval_line += "  ← NEW BEST!"
                    f.write(eval_line + "\n")
                    color = "\033[93m" if not is_best else "\033[93;1m"
                    print(f"{color}{eval_line}\033[0m")
                    f.write("-" * 80 + "\n")
            with open(
                os.path.join(args.output_dir, "log.txt"), mode="a", encoding="utf-8"
            ) as f:
                f.write(json.dumps(log_stats) + "\n")

        if args.test_run or args.eval_only:
            break

    if args.output_dir and train_losses and not args.eval_only:
        if distributed_mode.is_main_process():
            try:
               import matplotlib.pyplot as plt
               plt.figure(figsize=(15, 4))
               plt.subplot(1, 3, 1)
               plt.subplot(1, 3, 1)
               plt.plot(range(len(train_losses)), train_losses, 'b-', linewidth=2, label='Total Loss')
               if any(mse_loss > 0 for mse_loss in train_mse_losses):
                   plt.plot(range(len(train_mse_losses)), train_mse_losses, 'g--', linewidth=2, label='MSE Loss')
               if any(contrastive_loss > 0 for contrastive_loss in train_contrastive_losses):
                   plt.plot(range(len(train_contrastive_losses)), train_contrastive_losses, 'r:', linewidth=2,
                         label='Contrastive Loss')
               plt.title('Training Losses')
               plt.xlabel('Epoch')
               plt.ylabel('Loss')
               plt.legend()
               plt.grid(True, alpha=0.3)

               if eval_metrics['dice']:
                   plt.subplot(1, 3, 2)
                   epochs = [i * args.eval_frequency for i in range(len(eval_metrics['dice']))]
                   plt.plot(epochs, eval_metrics['dice'], 'g-', label='Dice', linewidth=2)
                   plt.plot(epochs, eval_metrics['ssim'], 'r-', label='SSIM', linewidth=2)
                   plt.title('Evaluation Metrics')
                   plt.xlabel('Epoch')
                   plt.ylabel('Score')
                   plt.legend()
                   plt.grid(True, alpha=0.3)


               if train_mse_losses and train_contrastive_losses:
                   plt.subplot(1, 3, 3)
                   plt.plot(range(len(train_mse_losses)), train_mse_losses, 'g-', linewidth=2, label='MSE Loss')
                   plt.plot(range(len(train_contrastive_losses)), train_contrastive_losses, 'r-', linewidth=2,
                            label='Contrastive Loss')
                   plt.title('Loss Components Comparison')
                   plt.xlabel('Epoch')
                   plt.ylabel('Loss')
                   plt.legend()
                   plt.grid(True, alpha=0.3)

               plt.tight_layout()
               plot_path = Path(args.output_dir) / "training_curves.png"
               plt.savefig(plot_path, dpi=300, bbox_inches='tight')
               plt.close()

               logger.info(f"Training curves saved to {plot_path}")

               loss_data = {
                'train_losses': train_losses,
                'train_mse_losses': train_mse_losses,
                'eval_metrics': eval_metrics
               }
               loss_data_path = Path(args.output_dir) / "loss_data.json"
               with open(loss_data_path, 'w') as f:
                   json.dump(loss_data, f, indent=2)

            except ImportError:
                logger.warning("Matplotlib not available, skipping plot generation")
            except Exception as e:
                logger.warning(f"Failed to generate plots: {e}")

    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    logger.info(f"Training time {total_time_str}")


if __name__ == "__main__":
    args = get_args_parserFMT()
    args = args.parse_args()
    if args.output_dir:
        Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    main(args)
