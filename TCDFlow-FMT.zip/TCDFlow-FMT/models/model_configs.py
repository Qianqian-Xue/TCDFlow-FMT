# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the CC-by-NC license found in the
# LICENSE file in the root directory of this source tree.
from typing import Union

from models.discrete_unet import DiscreteUNetModel
from models.ema import EMA
from models.unet import UNetModel

MODEL_CONFIGS = {
     "fmt_ddt_xs": {
        "input_size": 64,
        "patch_size": 2,
        "in_channels": 16,
        "encoder_dim": 256,
        "encoder_depth": 8,
        "encoder_heads": 4,
        "decoder_dim": 256,
        "decoder_depth": 4,
        "decoder_heads": 4,
        "mlp_ratio": 4.0,
        "condition_channels": 24,
        "class_dropout_prob": 0.1,
        "out_channels": 16,
     },
     "fmt_ddt_s": {
        "input_size": 64,
        "patch_size": 2,
        "in_channels": 16,
        "encoder_dim": 384,
        "encoder_depth": 12,
        "encoder_heads": 6,
        "decoder_dim": 384,
        "decoder_depth": 6,
        "decoder_heads": 6,
        "mlp_ratio": 4.0,
        "condition_channels": 24,
        "class_dropout_prob": 0.1,
        "out_channels": 16,
     },
}


def instantiate_model(
    architechture: str, is_discrete: bool, use_ema: bool
) -> Union[UNetModel, DiscreteUNetModel]:
    assert (
        architechture in MODEL_CONFIGS
    ), f"Model architecture {architechture} is missing its config."
    if architechture.startswith("fmt_ddt"):
        from models.DDT import DDT

        config = MODEL_CONFIGS[architechture]
        model = DDT(**config)
    elif is_discrete:
        if architechture + "_discrete" in MODEL_CONFIGS:
            config = MODEL_CONFIGS[architechture + "_discrete"]
        else:
            config = MODEL_CONFIGS[architechture]
        model = DiscreteUNetModel(
            vocab_size=257,
            **config,
        )
    else:
        model = UNetModel(**MODEL_CONFIGS[architechture])

    if use_ema:
        return EMA(model=model)
    else:
        return model
