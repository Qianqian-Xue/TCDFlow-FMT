from typing import List
from pathlib import Path
import json
from models.model_configs import instantiate_model
import torch
from training.eval_loopfmt import CFGScaledModel
from flow_matching.solver.ode_solver import ODESolver
import time
import torchvision.datasets as datasets
from FMTsdata import FMTsDataset
from torch.utils.data import DataLoader
from training.data_transform import get_train_transform, TransformDataset

from tqdm import tqdm
from functools import partial

import os
import numpy as np
import torch
import argparse
import torch.serialization
import matplotlib.pyplot as plt
import scipy.io as scio

from skimage.metrics import structural_similarity as ssim_sk
from skimage.metrics import peak_signal_noise_ratio as psnr_sk


def compute_metric(pred: torch.Tensor, gt: torch.Tensor):

    if pred.dim() == 5 and pred.shape[1] == 1:
        pred = pred.squeeze(1)
    if gt.dim() == 5 and gt.shape[1] == 1:
        gt = gt.squeeze(1)

    pred_vol = pred.cpu().numpy()
    gt_vol = gt.cpu().numpy()

    ssim_l, psnr_l, dice_l, nrmse_l, mae_l, le_l, cnr_l = [], [], [], [], [], [], []

    for b in range(pred_vol.shape[0]):
        p = np.clip(pred_vol[b], 0, 1)
        g = np.clip(gt_vol[b], 0, 1)

        ssim_l.append(ssim_sk(g, p, data_range=1.0))
        psnr_l.append(psnr_sk(g, p, data_range=1.0))


        thresh = max(0.1 * p.max(), 0.05)
        p_bin = (p > thresh)
        g_bin = (g > 0.02)

        dice = 2.0 * (p_bin & g_bin).sum() / (p_bin.sum() + g_bin.sum() + 1e-6)
        dice_l.append(dice)


        nrmse_l.append(np.sqrt(np.mean((p - g) ** 2)) / (g.max() - g.min() + 1e-8))
        mae_l.append(np.mean(np.abs(p - g)))

        if g_bin.sum() > 0 and p_bin.sum() > 0:
            g_center = np.argwhere(g_bin).mean(axis=0)
            p_center = np.argwhere(p_bin).mean(axis=0)
            le_mm = np.linalg.norm(g_center - p_center)
        else:
            le_mm = 999.0
        le_l.append(le_mm)

        target_mask = p > thresh
        background_mask = p <= thresh
        if np.sum(target_mask) > 0 and np.sum(background_mask) > 0:

            target_mean = np.mean(p[target_mask])
            background_mean = np.mean(p[background_mask])
            target_std = np.std(p[target_mask])
            background_std = np.std(p[background_mask])


            if target_std ** 2 + background_std ** 2 > 0:
                cnr = abs(target_mean - background_mean) / np.sqrt(target_std ** 2 + background_std ** 2)
            else:
                cnr = 0.0
        else:
            cnr = 0.0
        cnr_l.append(cnr)
    return (np.mean(ssim_l), np.mean(psnr_l), np.mean(dice_l),
            np.mean(nrmse_l), np.mean(mae_l), np.mean(le_l), np.mean(cnr_l))


# ================================================================================

def get_dataset(args_dict, ceshidata_dir):
    dataset = FMTsDataset(ceshidata_dir, test_flag=True)
    return dataset


def save_results(save_dir: Path, batch_id: int, batch_size: int,
                 gts: torch.Tensor, preds: torch.Tensor, labels: torch.Tensor = None, dice_score: float = 0.0,
                 cnr_score: float = 0.0, algorithm_name: str = "midpoint"):

    save_dir = save_dir / algorithm_name
    os.makedirs(save_dir, exist_ok=True)
    B = preds.shape[0]

    for i in range(B):
        idx = batch_id * batch_size + i

        pred_np = preds[i].cpu().numpy()
        gt_np = gts[i].cpu().numpy()


        plt.figure(figsize=(12, 5))


        plt.subplot(1, 2, 1)
        plt.imshow(gt_np[7], cmap='viridis', vmin=0, vmax=1)
        plt.colorbar(shrink=0.8)
        plt.axis('off')
        plt.title(f'GT Slice 7 - {idx}')


        plt.subplot(1, 2, 2)
        plt.imshow(pred_np[7], cmap='viridis', vmin=0, vmax=1)
        plt.colorbar(shrink=0.8)
        plt.axis('off')
        plt.title(f'Pred Slice 7 - {idx}\nDICE: {dice_score:.4f}, CNR: {cnr_score:.4f}')

        plt.tight_layout()
        plt.savefig(save_dir / f"compare_{idx:04d}_slice7.png", bbox_inches='tight', dpi=150)
        plt.close()


        scio.savemat(save_dir / f"recon_{idx:04d}.mat", {
            'reconstruction': pred_np.astype(np.float32),
            'ground_truth': gt_np.astype(np.float32),
        })


def main(args):
    torch.manual_seed(42)
    np.random.seed(42)
    checkpoint_path = Path(args.checkpoint)
    checkpoint_name = checkpoint_path.stem
    with open(checkpoint_path.parent / f"{args.filename}.txt", "a", encoding="utf-8") as file:
        file.write(f"checkpoint: {args.checkpoint}\n")
        file.write(f"cfg_scale: {args.cfg_scale}\n")
        file.write(f"n_ensemble: {args.n_ensemble}\n")
        file.write(f"batch_size: {args.batch_size}\n")
        file.write(f"sampling: {args.sampling}\n")
        file.write(f"ode_method: {args.ode_method}\n")
        file.write(f"ode_options: {args.ode_options}\n")

    args_filepath = checkpoint_path.parent / 'args.json'
    with open(args_filepath, 'r') as f:
        args_dict = json.load(f)
    # override args
    args_dict["cfg_scale"] = args.cfg_scale
    args_dict["n_ensemble"] = args.n_ensemble
    args_dict["batch_size"] = args.batch_size
    args_dict["ode_method"] = args.ode_method
    args_dict["ode_options"] = args.ode_options

    sample_resolution = args_dict['img_size']
    batch_size = args.batch_size
    print("batch_size:", batch_size)
    print("sample_resolution:", sample_resolution)

    dataset = get_dataset(args_dict, args.ceshidata_dir)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=8, pin_memory=True)

    model = instantiate_model(
        architechture=args_dict['dataset'] + ("_condition" if args_dict["condition"] else ""),
        is_discrete='discrete_flow_matching' in args_dict and args_dict['discrete_flow_matching'],
        use_ema=args_dict['use_ema'])
    torch.serialization.add_safe_globals([argparse.Namespace])  # for pytorch 2.6
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    model.load_state_dict(checkpoint["model"])
    #device = 'cuda'
    device = args.device
    model.to(device=device)
    cfg_weighted_model = CFGScaledModel(model)
    solver = ODESolver(velocity_model=cfg_weighted_model)

    ode_opts = args_dict['ode_options']
    sample_partial = partial(
        solver.sample,
        time_grid=torch.tensor([0.0, 1.0], device=device),
        method=args_dict['ode_method'],
        atol=ode_opts['atol'] if 'atol' in ode_opts else 1e-5,
        rtol=ode_opts['rtol'] if 'rtol' in ode_opts else 1e-5,
        step_size=(ode_opts['step_size'] if 'step_size' in ode_opts else None),
        cfg_scale=args_dict['cfg_scale'],
    )

    print("Discrete:", args_dict['discrete_flow_matching'])
    print("Condition:", args_dict['condition'])

    total_ssim = total_psnr = total_dice = total_nrmse = total_mae = total_le = total_cnr = 0.0
    total_sampling_time = 0.0  # 总采样时间
    total_samples = 0  # 总样本数
    num_batches = 0
    for batch_id, (gts, images) in enumerate(tqdm(dataloader, desc="Evaluating")):
        gts = gts.to(device)
        # gts = gts * 2.0 - 1.0
        labels = images.to(device)
        sampling_start_time = time.time()
        preds = []
        for i in range(args.n_ensemble):
            x_0 = torch.randn_like(gts)

            resample = sample_partial(x_init=x_0, label=labels)

            preds.append(resample)

        pred_stack = torch.stack(preds)
        final_pred = torch.zeros_like(pred_stack[0])

        for slice_idx in range(pred_stack.shape[2]):

            final_pred[:, slice_idx, :, :] = pred_stack[:, :, slice_idx, :, :].mean(0)

        sampling_end_time = time.time()
        batch_sampling_time = sampling_end_time - sampling_start_time
        total_sampling_time += batch_sampling_time
        total_samples += gts.size(0)

        print(f"Batch {batch_id}: Sampling time = {batch_sampling_time:.2f}s, "
              f"Average per sample = {batch_sampling_time / gts.size(0):.2f}s")
        final_pred = torch.clamp(final_pred * 0.5 + 0.5, 0, 1)
        ssim_val, psnr_val, dice_val, nrmse_val, mae_val, le_val, cnr_val = compute_metric(
            final_pred, gts
        )

        total_ssim += ssim_val
        total_psnr += psnr_val
        total_dice += dice_val
        total_nrmse += nrmse_val
        total_mae += mae_val
        total_le += le_val
        total_cnr += cnr_val
        num_batches += 1


        with open(checkpoint_path.parent / f"{args.filename}.txt", "a", encoding="utf-8") as file:
            file.write(f"Batch {batch_id} --- "
                       f"SSIM: {ssim_val:.4f} --- PSNR: {psnr_val:.2f} --- "
                       f"Dice: {dice_val:.4f} --- LE: {le_val:.2f}mm --- "
                       f"CNR: {cnr_val:.4f}\n"
                       f"Sampling Time: {batch_sampling_time:.2f}s --- "
                       f"Avg Per Sample: {batch_sampling_time / gts.size(0):.2f}s\n"
                       )

        save_results(
            save_dir=checkpoint_path.parent / args.filename,
            batch_id=batch_id,
            batch_size=args.batch_size,
            gts=gts,  # [B, 16, 64, 64]
            preds=final_pred1.cpu(),  # [B, 16, 64, 64]
            labels=images,
            dice_score=float(dice_val),
            cnr_score=float(cnr_val),
            algorithm_name=f"{args.ode_method}_step{args_dict['ode_options'].get('step_size', 'default')}_{checkpoint_name}"
        )

    if num_batches > 0:
        avg_ssim = total_ssim / num_batches
        avg_psnr = total_psnr / num_batches
        avg_dice = total_dice / num_batches
        avg_nrmse = total_nrmse / num_batches
        avg_mae = total_mae / num_batches
        avg_le = total_le / num_batches
        avg_cnr = total_cnr / num_batches

        with open(checkpoint_path.parent / f"{args.filename}.txt", "a", encoding="utf-8") as file:
            file.write(f"\nOverall Metrics --- "
                       f"SSIM: {avg_ssim:.4f} --- PSNR: {avg_psnr:.2f} --- "
                       f"Dice: {avg_dice:.4f} --- LE: {avg_le:.2f}mm --- "
                       f"CNR: {avg_cnr:.4f}\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process data based on version")
    parser.add_argument("--checkpoint", "-ckpt",
                        default="",
                        type=str, help="Specify the checkpoint")
    parser.add_argument("--batch_size", default=1, type=int, help="Override Batch size")
    parser.add_argument("--cfg_scale", default=0.2, type=float, help="Override classifier-free guidance scale")
    parser.add_argument("--n_ensemble", default=1, type=int, help="Override number of samples to ensemble")
    parser.add_argument("--filename", default="", type=str, help="Specify the eval filename")
    parser.add_argument("--sampling", default="random", type=str, choices=["random", "local"],
                        help="Specify the type of sampling for inference")
    parser.add_argument("--ode_method", default="", type=str, help="ODE method to use for sampling")
    parser.add_argument(
        "--device",
        default="",
        help="device to use for training / testing"
    )
    parser.add_argument("--ode_options", default='{"step_size":xx}', type=json.loads,
                        help="ODE solver options. Eg. the midpoint solver requires step-size, dopri5 has no options to set.")
    parser.add_argument(
        "--ceshidata_dir",
        default="",
        type=str,
        help="imagenet root folder with train, val and test subfolders",
    )
    args = parser.parse_args()

    main(args)
