import os
import h5py
from scipy.io import loadmat
import torch
from torch.utils.data import Dataset
import numpy as np
import matplotlib.pyplot as plt

class FMTsDataset(Dataset):
    def __init__(self, directory, test_flag=True,load_gt=True):
        self.directory = directory
        self.test_flag = test_flag
        base_numbers = list(range(1002, 1944))
        remove_numbers = [1022, 1049, 1114, 1108, 1117, 1066, 1086, 1201, 1081, 1140, 1473, 1487, 1497]  # 13个数据
        extra_numers = [73, 71, 80, 171, 116, 126, 215, 183, 239, 318, 691, 328, 353, 372, 402, 429, 452, 523, 589, 590,
                        660, 692, 776, 782, 790, 845, 935, 968, 945, 2112, 912, 959, 994, 2865, 3001, 2505, 994, 3834,
                        3885, 3905, 4163, 2091, 4852, 2254, 5082, 5164, 5187, 5402, 5541, 5555, 2418, 5885, 6318, 6328,
                        6413, 6438, 6523, 6715, 6840, 7093, 7214, 2493, 7818, 7940, 8523, 8713, 8732, 8893, 9199, 1976,
                        1980, 1982]
        self.numbers = list(set(base_numbers + extra_numers) - set(remove_numbers))
        self.numbers = list(range(6, 5001))
        self.guides = self._load_guide(os.path.join(directory, 'GUIDESNOISE'))
        self.x0s = self._load_x0(os.path.join(directory, 'x0'))


    def _load_guide(self, images_dir):
        guides = []

        for i in self.numbers:
            file_path = os.path.join(images_dir, f"img{i}.mat")
            data= h5py.File(file_path, 'r')
            data= np.transpose(data['combinedMatrix'])#就是原来的顺序:64*64*24
            data =np.transpose(data, (2, 0, 1))
            guides.append(data)
        guide_stack = np.stack(guides, axis=0)
        guide_stack = torch.tensor(guide_stack, dtype=torch.float32)
        print(guide_stack.shape)
        return guide_stack



    def _load_x0(self, x0s_dir):
        x0_slices = []
        for i in self.numbers:
            filename = f'{i}.mat'
            file_path = os.path.join(x0s_dir, f"{i}.mat")
            data = h5py.File(file_path, 'r')
            data = np.transpose(data['label_ThreeMatrix'])
            data = np.transpose(data, (2, 0, 1))
            x0_slices.append(data)
        x0_stack = np.stack(x0_slices, axis=0)
        x0_stack = torch.tensor(x0_stack, dtype=torch.float32)
        return x0_stack
    def __len__(self):
        return self.guides.shape[0]  # Number of channels (900 in this case)

    def __getitem__(self, x):
        # 确保索引在有效范围内
        guide = self.guides[x,:,:,:]
        x0 = self.x0s[x, :, :, :]
        return (x0, guide)

class Normalizer:
    def __init__(self):
        self.mean = None
        self.std = None
    def fit(self, train_data,save_path):

        self.mean = np.mean(train_data)
        self.std = np.std(train_data)
        print(f"Mean: {self.mean}, Variance: {self.std ** 2}")

        mean_path = save_path + 'mean.npy'
        std_path = save_path + 'std.npy'


        np.save(mean_path, self.mean)
        np.save(std_path, self.std)
    def transform(self, data):

        if self.mean is None or self.std is None:
            raise ValueError("Mean and standard deviation are not set. Call fit first.")


        return (data - self.mean) / (self.std + 1e-9)

def load_mean_std(save_path):
    mean_path = save_path + 'mean.npy'
    std_path = save_path + 'std.npy'
    mean = np.load(mean_path)
    std = np.load(std_path)
    return mean, std