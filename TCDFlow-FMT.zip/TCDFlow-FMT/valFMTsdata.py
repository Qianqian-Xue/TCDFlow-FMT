import os
import h5py
from scipy.io import loadmat
import torch
from torch.utils.data import Dataset
import numpy as np
import matplotlib.pyplot as plt

class valFMTsDataset(Dataset):
    def __init__(self, directory, test_flag=True):
        self.directory = directory
        self.test_flag = test_flag
        self.numbers = list(range(1, 5))
        self.guides = self._load_guide(os.path.join(directory, 'GUIDESNOISE'))
        self.x0s = self._load_x0(os.path.join(directory, 'x0'))


    def _load_guide(self, images_dir):
        guides = []
        for i in self.numbers:
            file_path = os.path.join(images_dir, f"img{i}.mat")
            data= h5py.File(file_path, 'r')
            data= np.transpose(data['combinedMatrix'])
            data =np.transpose(data, (2, 0, 1))
            guides.append(data)
        guide_stack = np.stack(guides, axis=0)
        guide_stack = torch.tensor(guide_stack, dtype=torch.float32)
        print(guide_stack.shape)
        return guide_stack



    def _load_x0(self, x0s_dir):
        x0_slices = []
        for i in self.numbers:
            filename = f'{i}.mat'
            file_path = os.path.join(x0s_dir, f"{i}.mat")
            data = h5py.File(file_path, 'r')
            data = np.transpose(data['label_ThreeMatrix'])
            data = np.transpose(data, (2, 0, 1))
            x0_slices.append(data)
        x0_stack = np.stack(x0_slices, axis=0)
        x0_stack = torch.tensor(x0_stack, dtype=torch.float32)
        return x0_stack
    def __len__(self):
        return self.guides.shape[0]

    def __getitem__(self, x):
        guide = self.guides[x, :, :, :]
        x0 = self.x0s[x, :, :, :]
        return (x0, guide)

class Normalizer:
    def __init__(self):
        self.mean = None
        self.std = None
    def fit(self, train_data,save_path):
        self.mean = np.mean(train_data)
        self.std = np.std(train_data)
        print(f"Mean: {self.mean}, Variance: {self.std ** 2}")
        mean_path = save_path + 'mean.npy'
        std_path = save_path + 'std.npy'

        np.save(mean_path, self.mean)
        np.save(std_path, self.std)
    def transform(self, data):

        if self.mean is None or self.std is None:
            raise ValueError("Mean and standard deviation are not set. Call fit first.")
        return (data - self.mean) / (self.std + 1e-9)

def load_mean_std(save_path):
    mean_path = save_path + 'mean.npy'
    std_path = save_path + 'std.npy'
    mean = np.load(mean_path)
    std = np.load(std_path)
    return mean, std